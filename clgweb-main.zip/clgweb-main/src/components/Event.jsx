const Event = () => {
    return (
<div class="event">
<h2 class="heading">College Event Calender</h2>
<div>
  <ul>
    <li>
      <span class="event-date">
        11 <br /> April{" "}
      </span>{" "}
      Lorem Ipsum is simply dummy text of the printing text printing
      industry...
    </li>
    <li>
      <span class="event-date">
        19 <br /> May{" "}
      </span>{" "}
      Lorem Ipsum is simply dummy text of the printing industry
      dummy text...
    </li>
    <li>
      <span class="event-date">
        21 <br /> June{" "}
      </span>{" "}
      Lorem Ipsum is simply dummy text of the printing industry orem
      Ipsum...
    </li>
    <li>
      <span class="event-date">
        17 <br /> July{" "}
      </span>{" "}
      Lorem Ipsum is simply dummy text of the printing industry
      simply dummy...
    </li>
    <li>
      <span class="event-date">
        31 <br /> August{" "}
      </span>{" "}
      Lorem Ipsum is simply dummy text of the printing industry...
    </li>
  </ul>
</div>
</div>
    )
}
export default Event;