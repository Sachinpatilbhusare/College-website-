import React from "react";

import "../style/style.css";


const Footer = () => {
  return (
    <div className="background2" id="Rooms">
      <div className="cont">
        <div className="main">
        <footer className="footer">
          <div className="footer1">
            
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure, dolorum!</p>
          </div>

          <div>
            <ul>
              <h1>College</h1><br />
              <li>About us</li>
              <li>Admission</li>
              <li>Contact us</li>
              <li>Feedback</li>
            </ul>
          </div>
          <div>
            <ul>
            <h1>Admission</h1><br />
              <li>Overview</li>
              <li>Admission FAQs</li>
              <li>Testimonial</li>
              <li>Contact US</li>
            </ul>
          </div>
          <div>
            <ul>
            <h1>Academics</h1><br />
              <li>Departments</li>
              <li>Faculty</li>
              <li>Academic Calender</li>
              <li>Examination</li>
            </ul>
          </div>
        </footer>
        <hr />
        <div className="footer_last">
          <p>@Copyright - College  All Rights Reserved</p>
        

        </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
