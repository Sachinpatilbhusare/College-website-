const CampusN = () => {
    return (

<div class="event campus-news">
<h2 class="heading">Campus News</h2>
<div>
  <ul>
    <li>
      <span class="campus-img">
        <img src="images/campus-1.png" alt="" />
      </span>
      <h2>There are many variations.</h2>
      <h6>Sep.04.2023</h6>
      <p>
        Lorem Ipsum is simply dummy text of the printing and
        typesetting industry...
      </p>
    </li>
    <li>
      <span class="event-img">
        <img src="images/campus-2.png" alt="" />
      </span>
      <h2>There are many variations.</h2>
      <h6>Sep.04.2023</h6>
      <p>
        Lorem Ipsum is simply dummy text of the printing and
        typesetting industry...
      </p>
    </li>
    <li>
      <span class="event-img">
        <img src="images/campus-3.png" alt="" />
      </span>
      <h2>There are many variations.</h2>
      <h6>Sep.04.2023</h6>
      <p>
        Lorem Ipsum is simply dummy text of the printing and
        typesetting industry...
      </p>
    </li>
    <li>
      <span class="event-img">
        <img src="images/campus-4.png" alt="" />
      </span>
      <h2>There are many variations.</h2>
      <h6>Sep.04.2023</h6>
      <p>
        Lorem Ipsum is simply dummy text of the printing and
        typesetting industry...
      </p>
    </li>
  </ul>
</div>
</div>
    )
}
export default CampusN;
