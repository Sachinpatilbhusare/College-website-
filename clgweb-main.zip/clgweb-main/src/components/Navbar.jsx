import React from "react";



import "../style/style.css";

const Navbar = () => {
  

  return (
    <>
      <div className="background">
        <nav className="container">
          <h1 class="text-white-800 text-3xl title-font font-medium mb-2">ABC College</h1>
          <ul>
           
                <li>
                  Home
                </li>
                <li>
                  Admission
                </li>
                <li>
             Campus
                </li>
                <li>
                 About
                </li>
                <li>
            Contact Us
                </li>
                <li>
           Training and Placement
                </li>
             
          </ul>
          <div className="float-right">

              <ul>
               
                  <button type="button" className="button">
                    Log in
                  </button>
               
               
                  <button type="button" className="button">
                    Sign up
                  </button>
               
                </ul>
              
          </div>
        </nav>
      </div>
    </>
  );
};

export default Navbar;
