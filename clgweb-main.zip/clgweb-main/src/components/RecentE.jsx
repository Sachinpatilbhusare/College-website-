const RecentE = () => {
    return (


<div class="event">
<h2 class="heading">Recent Event</h2>
<div>
  <marquee direction="up" scrollamount="7" style={{ height: 340 }}>
    <ul>
      <li>
        <i>05-May-2024 :</i> Lorem ipsum dolor sit amet,
        consectetur adipiscing elit. Ut elit tellus...{" "}
        <img src='images/logo.png' alt="" />
      </li>
      <li>
        <i>06-May-2024 :</i> Lorem ipsum dolor sit amet, consectetur
        adipiscing elit. Ut elit tellus...{" "}
        <img src="" alt="" />
      </li>
      <li>
        <i>07-May-2024 :</i> Lorem ipsum dolor sit amet,
        consectetur adipiscing elit. Ut elit tellus...{" "}
        <img src="" alt="" />
      </li>
      <li>
        <i>05-May-2024 :</i> Lorem ipsum dolor sit amet,
        consectetur adipiscing elit. Ut elit tellus...{" "}
        <img src="" alt="" />
      </li>
      <li>
        <i>06-May-2024 :</i> Lorem ipsum dolor sit amet,
        consectetur adipiscing elit. Ut elit tellus...{" "}
        <img src="" alt="" />
      </li>
      
     
    </ul>
  </marquee>
</div>
</div>
    )
}
export default RecentE;