import React from "react";
import "../style/style.css";
import RecentE from './RecentE'
import CampusN from './CampusN'
import Event from './Event'
;
// import Contact from './Contact';

const Home = () => {
  return (
    <>
      <div className="container1">
        <section class="text-gray-600 body-font overflow-hidden">
          <div class="container px-5 py-24 mx-auto">
            <div class="lg:w-4/5 mx-auto flex flex-wrap">
              <img
                alt="bg"
                style={{ height: 400 }}
                class="lg:w-1/2 w-full lg:h-auto h-64 object-cover object-center hover:scale-110"
                src=""
              />
              <div class="lg:w-1/2 w-full lg:pl-10 lg:py-6 mt-6 lg:mt-0">
                <h2 class="text-sm title-font text-white-500 tracking-widest hover:transition-all">
                  ABC College Of Science
                </h2>
                <h1 class="text-white-900 text-3xl title-font font-medium mb-1">
                  A++ grant
                </h1>
                <p class="leading-relaxed">
                  Lorem ipsum dolor sit amet consectetur, 
                  adipisicing elit. Doloribus minus repellendus dolore vel
                   molestiae aliquid qui esse autem inventore iusto eos omnis 
                   molestias quis, sint fugiat dignissimos totam laboriosam! Rem!
                </p>
              </div>
            </div>
          </div>
        </section>

        <div className="container">
<RecentE />
<Event />
<CampusN />
  
        </div>
      </div>
   
    </>
  );
};

export default Home;
